﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Enumerations
{
    public enum AccountType
    {
        Domestic,
        Savings,
        Foreign
    }
}
